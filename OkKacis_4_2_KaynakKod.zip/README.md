# Ok Kaçış 4.2 — Kalın, canlı ve kabartmalı oklar

Bu sürüm görsellerdeki ok bloğu referansını uygulamanın gerçek oyun taşlarına taşır.

- **6 renk × 4 yön × 3 uzunluk = 72** yeniden üretilmiş yüksek çözünürlüklü WebP oyun sprite'ı.
- Kısa ve uzun okların kalınlığı, kenar yuvarlatması, beyaz ok simgesi ve alt 3D çıkıntısı aynı ölçü sistemiyle hazırlanır.
- Eski soluk/pastel ve altın çerçeveli görünüm yerine canlı plastik oyuncak blok görünümü; tahta hücrelerine birebir kayıt.
- 540 bölüm, 20 can, iki dakikalık yenilenme, süre, çevrimdışı müzik, mağaza ve kaydetme anahtarları aynı kalır.
- Android 4.2.0, versionCode 14. Önceki 4.1 test sertifikasıyla APK v2 imzalandı; normal güncellemede ilerlemenin korunması amaçlanır.

**Test:** Üç ekran boyutunda yedi bölüm için tarayıcıda taş sınırları test edildi; APK ve içerik/şifreleme doğrulaması yapıldı. Gerçek cihaz kurulumu henüz doğrulanmadı.

**Dikkat:** Görseldeki bir ekran görüntüsünün birebir 3D modeli değil, referanstaki kalın parlak blok stilinin oyun arayüzüne uyarlanmış sürümüdür. Google Play gerçek ödeme bağlantısı içermez.

### Kaynak

- Android proje: `OkKacis/`
- Sprite oluşturucu: `make_sprites.py`
- APK oluşturucu: `build_v42.py` (aynı test anahtarını gerektirir; anahtar ZIP'e dahil değildir)
