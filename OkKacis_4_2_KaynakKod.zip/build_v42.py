from pathlib import Path
import struct, zipfile, hashlib, os, datetime
from cryptography import x509
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.x509.oid import NameOID

base=Path('/mnt/data/OkKacis_4_1_Parlak_Oklar_Net_Manzara.apk')
root=Path('/mnt/data/ok42/OkKacis/app/src/main/assets')
unsigned=Path('/mnt/data/OkKacis_4_2_Unsigned.apk')
out=Path('/mnt/data/OkKacis_4_2_Kalın_Parlak_3D_Oklar.apk')
keyfile=Path('/mnt/data/ok38/LOCAL_TEST_SIGNING_PRIVATE.pem')
certfile=Path('/mnt/data/ok38/LOCAL_TEST_SIGNING_CERT.der')

def patch_manifest(man):
 b=bytearray(man);p=8
 assert b[:4]==b'\x03\x00\x08\x00',b[:4]
 count=struct.unpack_from('<I',b,p+8)[0]
 flags=struct.unpack_from('<I',b,p+16)[0]
 start=struct.unpack_from('<I',b,p+20)[0]
 assert flags==0
 strings=[]; positions=[]
 for i in range(count):
  off=p+start+struct.unpack_from('<I',b,p+28+4*i)[0]
  ln=struct.unpack_from('<H',b,off)[0]
  assert not (ln&0x8000)
  s=b[off+2:off+2+2*ln].decode('utf-16le')
  strings.append(s);positions.append((off+2,ln))
 nameidx=strings.index('versionCode')
 manifest_off=None;off=8
 while off+8<=len(b):
  typ,head,size=struct.unpack_from('<HHI',b,off)
  if typ==0x0102:
   tag_idx=struct.unpack_from('<I',b,off+20)[0]
   if strings[tag_idx]=='manifest':manifest_off=off;break
  off+=size
 assert manifest_off is not None
 ast,asz,n=struct.unpack_from('<HHH',b,manifest_off+24)
 hits=0
 for i in range(n):
  pos=manifest_off+16+ast+i*asz
  if struct.unpack_from('<I',b,pos+4)[0]==nameidx:
   assert b[pos+15]==0x10
   assert struct.unpack_from('<I',b,pos+16)[0]==13
   struct.pack_into('<I',b,pos+16,14);hits+=1
 assert hits==1
 veridx=strings.index('4.1.0'); pos,ln=positions[veridx];assert ln==5
 b[pos:pos+10]='4.2.0'.encode('utf-16le')
 return bytes(b)

with zipfile.ZipFile(base,'r') as old,zipfile.ZipFile(unsigned,'w',allowZip64=False) as update:
 oldnames=set()
 for src in old.infolist():
  if src.filename.startswith('META-INF/') and src.filename!='META-INF/com/android/build/gradle/app-metadata.properties':continue
  oldnames.add(src.filename)
  content=old.read(src.filename)
  if src.filename=='AndroidManifest.xml':content=patch_manifest(content)
  if src.filename.startswith('assets/'):
   f=root/src.filename.removeprefix('assets/')
   if f.is_file():content=f.read_bytes()
  z=zipfile.ZipInfo(src.filename,date_time=src.date_time);z.compress_type=src.compress_type
  z.external_attr=src.external_attr
  if src.filename=='resources.arsc':
   assert z.compress_type==zipfile.ZIP_STORED
   offset=update.fp.tell();pad=(-offset-30-len(z.filename.encode())-4)%4
   z.extra=struct.pack('<HH',0xfffe,pad)+b'\0'*pad
  update.writestr(z,content)
 for f in sorted(root.rglob('*')):
  if not f.is_file():continue
  arc='assets/'+f.relative_to(root).as_posix()
  if arc in oldnames:continue
  z=zipfile.ZipInfo(arc,date_time=(2026,10,11,18,0,0));z.compress_type=zipfile.ZIP_DEFLATED
  update.writestr(z,f.read_bytes())

if keyfile.exists():
 private=serialization.load_pem_private_key(keyfile.read_bytes(),password=None)
else:
 private=rsa.generate_private_key(public_exponent=65537,key_size=3072)
 keyfile.write_bytes(private.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()))
 keyfile.chmod(0o600)
if certfile.exists(): certificate=x509.load_der_x509_certificate(certfile.read_bytes())
else:
 now=datetime.datetime.now(datetime.timezone.utc)
 name=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'Ok Kacis Test Signing 3.8'),x509.NameAttribute(NameOID.ORGANIZATION_NAME,'Ok Kacis Development')])
 certificate=x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(private.public_key()).serial_number(x509.random_serial_number()).not_valid_before(now-datetime.timedelta(days=1)).not_valid_after(now+datetime.timedelta(days=3650)).sign(private,hashes.SHA256())
 certfile.write_bytes(certificate.public_bytes(serialization.Encoding.DER))

SIG_MAGIC=b'APK Sig Block 42';SIG_ALGO=0x0103;V2_ID=0x7109871a
def lp(x):return struct.pack('<I',len(x))+x
def apk_digest(parts):
 digests=[]
 for part in parts:
  for i in range(0,len(part),1048576):
   block=part[i:i+1048576]
   digests.append(hashlib.sha256(b'\xa5'+struct.pack('<I',len(block))+block).digest())
 return hashlib.sha256(b'\x5a'+struct.pack('<I',len(digests))+b''.join(digests)).digest()
raw=unsigned.read_bytes()
eocd=raw.rfind(b'PK\x05\x06');assert eocd>0 and eocd+22==len(raw)
coff=struct.unpack_from('<I',raw,eocd+16)[0];assert raw[coff:coff+4]==b'PK\x01\x02'
digest=apk_digest([raw[:coff],raw[coff:eocd],raw[eocd:]])
data=lp(lp(struct.pack('<I',SIG_ALGO)+lp(digest)))+lp(lp(certificate.public_bytes(serialization.Encoding.DER)))+lp(b'')
sig=private.sign(data,padding.PKCS1v15(),hashes.SHA256())
signer=lp(data)+lp(lp(struct.pack('<I',SIG_ALGO)+lp(sig)))+lp(private.public_key().public_bytes(serialization.Encoding.DER,serialization.PublicFormat.SubjectPublicKeyInfo))
pairdata=lp(lp(signer))
pair=struct.pack('<Q',4+len(pairdata))+struct.pack('<I',V2_ID)+pairdata
size=len(pair)+24
block=struct.pack('<Q',size)+pair+struct.pack('<Q',size)+SIG_MAGIC
assert len(block)==size+8
end=bytearray(raw[eocd:]);struct.pack_into('<I',end,16,coff+len(block))
out.write_bytes(raw[:coff]+block+raw[coff:eocd]+end)

# Independent integrity verification for the V2 signature.
new=out.read_bytes();new_eocd=new.rfind(b'PK\x05\x06');new_off=struct.unpack_from('<I',new,new_eocd+16)[0]
assert new[new_off-16:new_off]==SIG_MAGIC
sz=struct.unpack_from('<Q',new,new_off-24)[0];assert sz==size
assert new_off-sz-8==coff
private.public_key().verify(sig,data,padding.PKCS1v15(),hashes.SHA256())
assert apk_digest([new[:coff],new[new_off:new_eocd],raw[eocd:]])==digest
with zipfile.ZipFile(out) as apk:
 assert apk.testzip() is None
 names=set(apk.namelist())
 assert len([n for n in names if n.startswith('assets/sprites/')])==72
 for n in ['assets/game.js','assets/style.css','assets/sprites/blue-s-R.webp','assets/sprites/green-l-U.webp','assets/world-forest.jpg','assets/world-forest-sharp.webp']:
  assert n in names and len(apk.read(n))>500
 assert '4.2.0'.encode('utf-16le') in apk.read('AndroidManifest.xml')
 print('APK:',out,'SIZE:',out.stat().st_size,'FILES:',len(names),'VERSION: 4.2.0 (code14)')
 print('V2 signature:',sig[:12].hex(), 'digest:',digest.hex())
 print('fingerprint:',certificate.fingerprint(hashes.SHA256()).hex())
