from pathlib import Path
from playwright.sync_api import sync_playwright
import base64, re
root=Path('/mnt/data/ok42/OkKacis/app/src/main/assets')
html=(root/'index.html').read_text()
css=(root/'style.css').read_text()
js=(root/'game.js').read_text()
for basename in ['world-forest-sharp.webp','world-forest.jpg']:
 css=css.replace(f"url('{basename}')",f"url('data:image/{'webp' if basename.endswith('.webp') else 'jpeg'};base64,{base64.b64encode((root/basename).read_bytes()).decode()}')")
html=html.replace('<link rel="stylesheet" href="style.css">','<style>'+css+'</style>')
html=html.replace('<script src="game.js"></script>','<script>'+js+'</script>')
data={f.stem: 'data:image/webp;base64,'+base64.b64encode(f.read_bytes()).decode() for f in (root/'sprites').glob('*.webp')}
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for width,height in [(393,852),(360,740),(430,932)]:
  page=browser.new_page(viewport={'width':width,'height':height},device_scale_factor=1)
  errors=[];page.on('pageerror',lambda exc: errors.append(str(exc)))
  page.set_content(html,wait_until='domcontentloaded')
  page.evaluate('document.querySelector("#splash").hidden=true')
  for n in [1,6,15,20,50,128,540]:
   page.evaluate('(n)=>window.__okKacisTest.startLevel(n)',n)
   page.evaluate('''(data) => {for(const el of document.querySelectorAll('.piece')){const bg=el.style.getPropertyValue('--tile-image');const name=(bg.match(/sprites\\/([^']+)\\.webp/)||[])[1];if(name)el.style.setProperty('--tile-image', `url("${data[name]}")`);}}''',data)
   page.wait_for_timeout(60)
   box=page.evaluate('''() => {const bd=document.querySelector('#gameBoard').getBoundingClientRect();return {b:{x:bd.x,y:bd.y,w:bd.width,h:bd.height},items:[...document.querySelectorAll('.piece')].map(el=>{const r=el.getBoundingClientRect();return {x:r.x,y:r.y,w:r.width,h:r.height,bg:getComputedStyle(el.querySelector('.piece-inner')).backgroundImage};})}}''')
   b=box['b'];assert box['items'],n
   for t in box['items']:
    assert t['x']>=b['x']-.8 and t['y']>=b['y']-.8,(n,t,b)
    assert t['x']+t['w']<=b['x']+b['w']+1 and t['y']+t['h']<=b['y']+b['h']+1,(n,t,b)
    assert 'data:image/webp' in t['bg'],(n,t['bg'][:120])
   if n in (1,15):page.screenshot(path=f'/mnt/data/ok42/level{n}_{width}x{height}.png')
  assert not errors,(width,errors)
  print('PASS',width,height,'7 stages & registered sprites')
  page.close()
 browser.close()
