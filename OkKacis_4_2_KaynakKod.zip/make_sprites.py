"""Generate uniformly raised, glossy toy-style arrow bricks for the Android game.
Colours, sizes, and bevel geometry match across 1/2/3-grid sprites. No image generation.
"""
from pathlib import Path
import colorsys
from PIL import Image, ImageDraw, ImageFilter
import numpy as np

OUT = Path('/mnt/data/ok42/OkKacis/app/src/main/assets/sprites')
OUT.mkdir(parents=True, exist_ok=True)
CELL = 180
# Saturated toy-plastic tones matched to the supplied arrow-block game reference.
COLORS = {
  'red': (255,38,57),
  'green': (0,228,67),
  'blue': (0,149,255),
  'orange': (255,119,10),
  'purple': (165,30,239),
  'yellow': (255,198,0),
}

def mix(c1, c2, ratio):
  return tuple(int(a*(1-ratio)+b*ratio) for a,b in zip(c1,c2))

def dark(c, val): return mix(c,(0,0,0),val)
def light(c, val): return mix(c,(255,255,255),val)

def face_gradient(w,h,color):
  # Very saturated, *not pastel*: centre rich, slight depth and natural lighting.
  y=np.linspace(0,1,h,dtype=np.float32)[:,None]
  x=np.linspace(0,1,w,dtype=np.float32)[None,:]
  t=np.broadcast_to(y,(h,w))
  shade=1.04 - .07*t - .12*(t**3) + .09*np.exp(-((t-.12)/.12)**2)
  shade=shade + .035*(.5-x)
  arr=np.zeros((h,w,4),dtype=np.uint8)
  for ch,val in enumerate(color):
    arr[:,:,ch]=np.clip(val*shade,0,255).astype(np.uint8)
  arr[:,:,3]=255
  return Image.fromarray(arr,'RGBA')

def points_for(cx,cy,dir,c=CELL,long=False):
  # Big, thick, recognizable white arrow centered in a block, independent of length.
  a = c*(.49 if long else .36) # long pieces use a slightly larger glyph
  s = c*.12 # shaft half thickness
  h = c*.32 # head half thickness
  tip = c*(.49 if long else .39)
  pts = [(cx-a,cy-s),(cx+.05*c,cy-s),(cx+.05*c,cy-h),(cx+tip,cy),
         (cx+.05*c,cy+h),(cx+.05*c,cy+s),(cx-a,cy+s)]
  def rotate(pt):
    x,y=pt; dx,dy=x-cx,y-cy
    if dir=='L':return (cx-dx,cy-dy)
    if dir=='U':return (cx+dy,cy-dx)
    if dir=='D':return (cx-dy,cy+dx)
    return pt
  return [rotate(p) for p in pts]

def make(color,n,direction):
  w,h=((CELL*n,CELL) if direction in ('R','L') else (CELL,CELL*n))
  base=COLORS[color]
  out=Image.new('RGBA',(w,h),(0,0,0,0))
  # Exterior cast shadow, low and substantial, remains inside allotted cells.
  shadow=Image.new('RGBA',(w,h),(0,0,0,0))
  s=ImageDraw.Draw(shadow)
  s.rounded_rectangle((11,23,w-10,h-6),radius=25,fill=(5,18,37,190))
  shadow=shadow.filter(ImageFilter.GaussianBlur(5))
  out.alpha_composite(shadow)
  d=ImageDraw.Draw(out)
  # 3D extruded bottom, darker face and side rim.
  d.rounded_rectangle((8,14,w-9,h-10),radius=25,fill=dark(base,.58))
  d.rounded_rectangle((9,11,w-11,h-22),radius=24,fill=dark(base,.30))
  d.rounded_rectangle((11,10,w-13,h-25),radius=23,fill=light(base,.23))
  face=face_gradient(w,h,base)
  mask=Image.new('L',(w,h),0)
  md=ImageDraw.Draw(mask)
  md.rounded_rectangle((15,14,w-17,h-29),radius=22,fill=255)
  face.putalpha(mask)
  out.alpha_composite(face)
  d=ImageDraw.Draw(out)
  # Strong raised edge, one crisp highlight; *no gold border*.
  d.rounded_rectangle((12,11,w-15,h-26),radius=24,outline=light(base,.58),width=4)
  d.rounded_rectangle((17,17,w-20,h-34),radius=19,outline=light(base,.22),width=2)
  d.line([(27,19),(w-29,19)],fill=(255,255,255,190),width=5)
  # Small upper-left gleam only, avoiding the big white wash of the old sprite.
  glint=Image.new('RGBA',(w,h))
  g=ImageDraw.Draw(glint)
  g.ellipse((18,15,75,67),fill=(255,255,255,98))
  glint=glint.filter(ImageFilter.GaussianBlur(14))
  out.alpha_composite(glint)
  d=ImageDraw.Draw(out)
  # Visible thick dark bottom ledge, reference-style toy block extrusion.
  d.rounded_rectangle((11,11,w-16,h-29),radius=24,outline=light(base,.32),width=2)
  # White chunky arrow with blue/slate drop extrusion, no sprite overlap.
  cx,cy=w/2,(h-13)/2
  pts=points_for(cx,cy,direction,long=(n>1))
  # Soft shadow under glyph
  arshadow=Image.new('RGBA',(w,h),(0,0,0,0))
  ad=ImageDraw.Draw(arshadow)
  ad.polygon([(x+2,y+11) for x,y in pts],fill=(0,16,35,175))
  arshadow=arshadow.filter(ImageFilter.GaussianBlur(4))
  out.alpha_composite(arshadow)
  d=ImageDraw.Draw(out)
  d.polygon([(x,y+7) for x,y in pts],fill=(13,76,128,255))
  d.polygon(pts,fill=(255,255,255,255))
  d.line(pts+[pts[0]],fill=(241,249,255,255),width=4,joint='curve')
  # White rim highlight along top edge of glyph to suggest embossed plastic.
  # Kept subtle to preserve a clean simple arrow shape.
  return out

for name in COLORS:
  for n,label in ((1,'s'),(2,'l'),(3,'xl')):
    for direction in 'RLUD':
      im=make(name,n,direction)
      im.save(OUT/f'{name}-{label}-{direction}.webp',format='WEBP',quality=99,method=5)
print('Created',len(list(OUT.glob('*.webp'))),'new uniform 3D sprites')
